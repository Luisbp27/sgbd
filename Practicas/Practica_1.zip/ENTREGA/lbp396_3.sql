/* Extreure el codi de l'albarà i el nom del proveidor de tots aquells albarans facturats que tenen alguna linea sense especificar-ne el preu */
SELECT
    ALBARA.CODI,
    PROVEIDOR.NOM
FROM
    ALBARA
    JOIN PROVEIDOR ON ALBARA.NIF_PRO = PROVEIDOR.NIF
WHERE
    ALBARA.FACTURAT = 'S'
    AND ALBARA.CODI IN (
        SELECT
            CODI_ALB
        FROM
            LINIA_ALBARA
        WHERE
            PREU IS NULL
    );