/* En un moment determinat es desactiva la clau primària de la taula VENDA. En tornar a activar-la dóna un error de codi duplicat. Mostra els codis que hi ha duplicats a la taula VENDA */
SELECT
    CODI
FROM
    VENDA
GROUP BY
    CODI
HAVING
    COUNT(*) > 1;
