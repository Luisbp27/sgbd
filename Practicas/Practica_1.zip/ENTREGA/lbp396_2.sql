/* Obtenirla referència i el nom de tots els aliments que ens han servit el proveidor que es diu "UIBFruita". Donar el resultat ordenat ascendentment per referència */
SELECT
    ALIMENT.REFERENCIA,
    ALIMENT.NOM
FROM
    ALIMENT
    JOIN LINIA_ALBARA ON ALIMENT.REFERENCIA = LINIA_ALBARA.REFERENCIA
    JOIN ALBARA ON LINIA_ALBARA.CODI_ALB = ALBARA.CODI
    JOIN PROVEIDOR ON ALBARA.NIF_PRO = PROVEIDOR.NIF
WHERE
    PROVEIDOR.NOM = 'UIBFruita'
ORDER BY
    ALIMENT.REFERENCIA ASC;